function(doc, req) { return true; }
