Basic CouchDB API: couchdb.client
=================================

.. automodule:: couchdb.client


Server
------

.. autoclass:: Server
   :members:


Database
--------

.. autoclass:: Database
   :members:


Document
--------

.. autoclass:: Document
   :members:


ViewResults
-----------

.. autoclass:: ViewResults
   :members:


Row
---

.. autoclass:: Row
   :members:
